#!/bin/bash
RD="\e[91m"
GR="\e[92m"
CY="\e[96m"
YL="\e[93m"
BL="\e[94m"
NC="\e[0m"
clear
echo -ne "[${YL}?${NC}] Your fu*king list = "
read list
if [[ ! -f $list ]]; then
	echo -e "[${RD}!${NC}] I can't find your fu*king list!"
	exit 1
fi


getting(){
	RD="\e[91m"
	GR="\e[92m"
	CY="\e[96m"
	YL="\e[93m"
	BL="\e[94m"
	NC="\e[0m"
	ip=$1
	tnt=$(curl -s -I -A "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:65.0) Gecko/20100101 Firefox/65.0" "$ip/")
	if [[ $tnt =~ "x-frame-options" ]]; then
		echo -e "Gagal kang"
	else
		echo "$ip/" >> clickjacking.txt
		echo "Send To Telegram"
		curl -s "https://api.telegram.org/bot{2125246923:AAGdbu32Ysjdtzn96aI-BT7SQrxwXnAQ2qY}/sendMessage?text={clickjacking - ${ip}}&chat_id={1851935675}"
	fi
}
export -f getting
echo -e "===============[Let's Go!]==============="
sort -u $list | xargs -P 50 -n1 bash -c 'getting "$@"' _
